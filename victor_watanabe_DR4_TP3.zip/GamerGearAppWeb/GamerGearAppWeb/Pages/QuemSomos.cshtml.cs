using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GamerGearAppWeb.Pages
{
    public class QuemSomosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
